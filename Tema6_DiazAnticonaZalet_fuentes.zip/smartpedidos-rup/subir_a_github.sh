#!/bin/bash
# 1) Crea un repo VACIO y PUBLICO en github.com llamado smartpedidos-rup
# 2) Cambia TU_USUARIO y ejecuta este script dentro de esta carpeta
git init && git branch -M main
git add docs/vision && git commit -m "docs(vision): Vision v1 con OB-01..OB-03 [I1]"
git add docs/srs docs/riesgos && git commit -m "docs(srs): SRS breve y riesgos [RF-01..RF-08]"
git add modelo planificacion && git commit -m "feat(modelo): actividad CU-02, clases y estados [CU-02, RF-03, RF-04, RF-07]"
git add . && git commit -m "docs(revision): checklist de coherencia y hallazgos H-01..H-05"
git remote add origin https://github.com/TU_USUARIO/smartpedidos-rup.git
git tag -a v1.0-iter1 -m "Iteracion 1"
git push -u origin main --tags
