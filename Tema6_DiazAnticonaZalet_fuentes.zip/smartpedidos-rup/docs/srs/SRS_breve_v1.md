# SRS breve v1
| ID | Requisito | Origen |
|---|---|---|
| RF-01 | Registrar e iniciar sesión de clientes | OB-01 |
| RF-02 | Consultar catálogo y gestionar carrito | OB-01 |
| RF-03 | Validar disponibilidad y reservar stock | OB-03 |
| RF-04 | Procesar pago (tarjeta y Yape) con rechazo y timeout | OB-02 |
| RF-05 | Confirmar pedido y emitir comprobante | OB-01 |
| RF-06 | Gestionar preparación y despacho | OB-01 |
| RF-07 | Cancelar pedido y reembolsar | OB-02 |
| RF-08 | Reporte de ventas | OB-01 |
| RNF-01 | Carrito y pago < 3 s (p95) | – |
| RNF-02 | Disponibilidad 99 % | – |
| RNF-03 | No almacenar datos de tarjeta (PCI por delegación) | OB-02 |

HU-01 (RF-02, CU-01) · HU-02 (RF-04, CU-02) · HU-03 (RF-03, CU-02) · HU-04 (RF-06, CU-03) · HU-05 (RF-07, CU-04) · HU-06 (RF-08, CU-05)
