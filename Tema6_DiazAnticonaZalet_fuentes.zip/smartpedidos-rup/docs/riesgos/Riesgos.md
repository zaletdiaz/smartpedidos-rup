# Riesgos
| ID | Fase | Riesgo | Mitigación | Iter. |
|---|---|---|---|---|
| R-01 | Inicio/Elab. | Integración con pasarela compleja | Prototipo sandbox y spike | E1 |
| R-02 | Elaboración | Arquitectura no soporta picos | Prueba de carga sobre esqueleto | E2 |
| R-03 | Elab./Const. | Inconsistencias de stock concurrente | Bloqueo optimista y pruebas | E2, C2 |
| R-04 | Construcción | Cambios de alcance | Control de cambios por iteración | C1–C3 |
| R-05 | Inicio | Requisitos ambiguos | Validar Visión con el dueño | I1 |
| R-06 | Construcción | Baja disponibilidad del equipo | Iteraciones cortas, holgura | C3 |
| R-07 | Transición | Resistencia al cambio | Capacitación y manual | T1 |
| R-08 | Transición | Defectos críticos en piloto | Pruebas de aceptación y rollback | T1 |
