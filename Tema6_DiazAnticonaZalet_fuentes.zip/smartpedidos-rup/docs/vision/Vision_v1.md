# Documento de Visión v1 – SmartPedidos
**Problema:** los pedidos manuales (WhatsApp/llamadas) causan sobreventa, pagos perdidos y demoras.
**Objetivos:** OB-01 reducir tiempo de atención · OB-02 aceptar pagos en línea (tarjeta y Yape) · OB-03 eliminar sobreventa con reserva de stock.
**Interesados:** cliente, almacenero, administrador, repartidor.
**Alcance:** catálogo y carrito, validación/reserva de stock, pago en línea, confirmación y comprobante, despacho, cancelación/reembolso, reporte de ventas.
**Fuera de alcance:** fidelización, facturación electrónica avanzada, app GPS de repartidores, multitienda.
**Restricciones:** equipo de 4, 14 semanas, no almacenar datos de tarjeta.
