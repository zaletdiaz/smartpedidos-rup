# SmartPedidos – Tema 6 (RUP + UML)
Plataforma de pedidos en línea con pago y delivery para una bodega en Lima. Iteración publicada: v1.0-iter1.
Estructura: docs/ (Visión, SRS, riesgos, checklist) · modelo/ (diagramas) · planificacion/ (roadmap, matriz) · evidencias/
