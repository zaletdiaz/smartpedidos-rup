# Roadmap
I1 (S1-2) Visión, riesgos · E1 (S3-4) SRS, CU-02, actividad · E2 (S5-6) clases, estados, secuencia, esqueleto (LCA)
C1 (S7-8) CU-01 · C2 (S9-10) CU-02 · C3 (S11-12) CU-03/04/05 (IOC) · T1 (S13-14) manual, despliegue (PR)
Matriz fase–artefacto: ver informe PDF, Paso 3.
